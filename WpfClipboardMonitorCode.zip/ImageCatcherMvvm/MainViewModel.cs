﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace ImageCatcherMvvm
{
    public class MainViewModel
    {
        private string path;

        public DelegateCommand ClipboardUpdateCommand { get; private set; }

        public MainViewModel()
        {
            this.ClipboardUpdateCommand = new DelegateCommand(OnClipboardUpdate, OnCanClipboardUpdate);

            this.path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Clipboard");
            Directory.CreateDirectory(this.path);
        }

        public void OnClipboardUpdate()
        {
            if (Clipboard.ContainsImage())
            {
                string filePath = Path.Combine(this.path, $"Image_{DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss")}.jpg");
                using (var file = File.Create(filePath))
                {
                    JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(Clipboard.GetImage()));
                    encoder.Save(file);
                }
            }
        }

        public bool OnCanClipboardUpdate()
        {
            return true;
        }
    }
}
